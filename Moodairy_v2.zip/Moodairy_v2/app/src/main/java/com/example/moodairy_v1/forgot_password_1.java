package com.example.moodairy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class forgot_password_1 extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_send_code, btn_back;
    EditText et_input_email,et_input_phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_forgot_password_1);

        btn_back = findViewById(R.id.btn_back_white);
        btn_send_code =findViewById(R.id.btn_send_code);
        et_input_email = findViewById(R.id.et_input_email_forgot);
        et_input_phone = findViewById(R.id.et_input_phone_forgot);

        btn_send_code.setOnClickListener(this);
        btn_back.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        Intent usr_data = getIntent();
        String USER_EMAIL = usr_data.getStringExtra("USER_EMAIL");
        String USER_PHONE = usr_data.getStringExtra("USER_PHONE");
        if(view == btn_back){
            Intent intent = new Intent(forgot_password_1.this, MainActivity.class);
            startActivity(intent);
        }
        if(view == btn_send_code){
           if( et_input_phone.getText().toString().equals(USER_PHONE) && et_input_email.getText().toString().equals(USER_EMAIL)){
               // sending code
               Toast.makeText(this,"Yes",Toast.LENGTH_LONG).show();
               int code = (int) (Math.random()*(999999-100000+1));
               Intent intent = new Intent(forgot_password_1.this,forgot_passwod_2.class);
               intent.putExtra("CODE",code);
               startActivity(intent);
           }
           else{
               Toast.makeText(this,"Your email or/and phone number are incorrect. Please check and try again",Toast.LENGTH_LONG).show();
           }
        }

    }

}
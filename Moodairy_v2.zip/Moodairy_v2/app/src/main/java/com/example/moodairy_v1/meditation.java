package com.example.moodairy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class meditation extends AppCompatActivity implements View.OnClickListener {
    ImageView breath;
    ImageButton btn_back, btn_music_lib, btn_set, btn_reset, btn_pause,btn_start;
    TextView time,tv_inhale, tv_exhale, tv_hold;
    EditText input_time;
    Animation inhale, exhale,hold, fade_in, fade_out, hold_text, inhale_text,exhale_text;



    private CountDownTimer mCountDownTimer;

    private boolean mTimerRunning;

    private long mStartTimeInMillis;
    private long mTimeLeftInMillis;
    private long mEndTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_meditation);
        exhale = AnimationUtils.loadAnimation(this,R.anim.inhale_anim);
        inhale = AnimationUtils.loadAnimation(this, R.anim.exhale_anim);
        hold = AnimationUtils.loadAnimation(this,R.anim.hold_anim);
        fade_in = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        fade_out = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        inhale_text =  AnimationUtils.loadAnimation(this, R.anim.exhale_text);
        exhale_text = AnimationUtils.loadAnimation(this,R.anim.inhale_text);
        hold_text =  AnimationUtils.loadAnimation(this,R.anim.hold_text);

        breath = findViewById(R.id.breath);
        btn_back = findViewById(R.id.btn_backk);
        btn_set = findViewById(R.id.btn_set);
        btn_music_lib = findViewById(R.id.btn_music_lib);
        btn_pause = findViewById(R.id.btn_pause);
        btn_reset = findViewById(R.id.btn_reset);
        time = findViewById(R.id.tv_time);
        btn_start = findViewById(R.id.btn_start);
        input_time = findViewById(R.id.input_time);

        tv_exhale = findViewById(R.id.tv_exhale);
        tv_hold = findViewById(R.id.tv_hold);
        tv_inhale = findViewById(R.id.tv_inhale);




        btn_music_lib.setOnClickListener(this);
        btn_back.setOnClickListener(this);
        btn_set.setOnClickListener(this);
        btn_reset.setOnClickListener(this);
        btn_pause.setOnClickListener(this);
        btn_start.setOnClickListener(this);

        tv_inhale.setVisibility(View.INVISIBLE);
        tv_exhale.setVisibility(View.INVISIBLE);
        tv_hold.setVisibility(View.INVISIBLE);


    }

    @Override
    public void onClick(View view) {
        if(view == btn_set){
            String input = input_time.getText().toString();
            if (input.length() == 0) {
                Toast.makeText(this, "Field can't be empty", Toast.LENGTH_SHORT).show();
                return;
            }
            long millisInput = Long.parseLong(input) * 60000;
            if (millisInput == 0) {
                Toast.makeText(this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
                return;
            }
            setTime(millisInput);
        }
        if(btn_back == view){
            Intent intent = new Intent(meditation.this, home_screen.class);
            startActivity(intent);
        }
        if(view == btn_reset){
            stopTimer();

        }
        if( view == btn_pause ){
            if (mTimerRunning) {
                pauseTimer();
            } else {
                startTimer();
            }
        }
        if( view == btn_start ){
            startAnim();
            startAnimText();
            if (mTimerRunning) {
                pauseTimer();
            } else {
                startTimer();
            }
        }



    }
    private void setTime(long milliseconds){
        mStartTimeInMillis = milliseconds;
       resetTimer();
       closeKeyboard();
    }
    private void pauseTimer() {
        stopAnim();
        mCountDownTimer.cancel();
        mTimerRunning = false;
        updateWatchInterface();
    }
    private void startTimer() {
        mEndTime = System.currentTimeMillis() + mTimeLeftInMillis;
        if(mTimeLeftInMillis==0){
            Toast.makeText(this, "Timer can't start without a input time. Please enter the desired time.", Toast.LENGTH_SHORT).show();
        }
        else {
            mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    mTimeLeftInMillis = millisUntilFinished;
                    updateCountDownText();
                }

                @Override
                public void onFinish() {
                    mTimerRunning = false;
                    updateWatchInterface();
                }
            }.start();
            mTimerRunning = true;
            updateWatchInterface();
        }
    }
    private void resetTimer() {
        mTimeLeftInMillis = mStartTimeInMillis;
        updateCountDownText();
        updateWatchInterface();

    }
    private void stopTimer(){
       stopAnim();
        mTimeLeftInMillis=0;
        updateCountDownText();
        mCountDownTimer.cancel();
        mTimerRunning = false;
        input_time.setText("");
        input_time.setVisibility(View.VISIBLE);
        time.setVisibility(View.INVISIBLE);
        btn_reset.setVisibility(View.INVISIBLE);
        btn_set.setVisibility(View.VISIBLE);
        btn_start.setVisibility(View.VISIBLE);
        btn_pause.setVisibility(View.INVISIBLE);

    }
    private void updateCountDownText() {
        int minutes = (int) mTimeLeftInMillis/1000/60;
        int seconds = (int) (mTimeLeftInMillis/1000)%60;

        String timeLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        time.setText(timeLeftFormatted);
    }
    private void updateWatchInterface() {
        if (mTimerRunning) {
            input_time.setVisibility(View.INVISIBLE);
            btn_set.setVisibility(View.INVISIBLE);
            btn_reset.setVisibility(View.VISIBLE);
            btn_start.setVisibility(View.INVISIBLE);
            btn_pause.setVisibility(View.VISIBLE);
            time.setVisibility(View.VISIBLE);
        } else {
            btn_start.setVisibility(View.VISIBLE);
            if (mTimeLeftInMillis < 1000) {
                btn_pause.setVisibility(View.INVISIBLE);
                input_time.setVisibility(View.VISIBLE);
                btn_set.setVisibility(View.VISIBLE);
                btn_reset.setVisibility(View.INVISIBLE);
                btn_start.setVisibility(View.VISIBLE);
                time.setVisibility(View.INVISIBLE);
                stopTimer();
            } else {
                btn_pause.setVisibility(View.VISIBLE);
                btn_set.setVisibility(View.INVISIBLE);
            }
            if (mTimeLeftInMillis < mStartTimeInMillis) {
                btn_reset.setVisibility(View.VISIBLE);
            } else {
                btn_reset.setVisibility(View.INVISIBLE);
                btn_set.setVisibility(View.VISIBLE);
            }
        }
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    private void startAnim(){
        breath.startAnimation(inhale);
        exhale.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation){breath.startAnimation(inhale);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        hold.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                breath.startAnimation(exhale);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        inhale.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                breath.startAnimation(hold);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

    }
    public void startAnimText(){
        tv_inhale.setVisibility(View.VISIBLE);
        tv_inhale.startAnimation(inhale);
        inhale_text.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
               // tv_inhale.startAnimation(fade_in);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
               // tv_inhale.startAnimation(fade_out);
                tv_inhale.setVisibility(View.INVISIBLE);
                tv_hold.setVisibility(View.VISIBLE);
                tv_hold.startAnimation(hold_text);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        hold_text.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
               // tv_hold.startAnimation(fade_in);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //tv_hold.startAnimation(fade_out);
                tv_hold.setVisibility(View.INVISIBLE);
                tv_exhale.setVisibility(View.VISIBLE);
                tv_exhale.startAnimation(exhale_text);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        exhale_text.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                //tv_exhale.startAnimation(fade_in);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
               // tv_exhale.startAnimation(fade_out);
                tv_exhale.setVisibility(View.INVISIBLE);
                tv_inhale.setVisibility(View.VISIBLE);
                tv_inhale.startAnimation(inhale_text);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
    public void stopAnim(){
        tv_inhale.setVisibility(View.INVISIBLE);
        tv_hold.setVisibility(View.INVISIBLE);
        tv_exhale.setVisibility(View.INVISIBLE);
        exhale_text.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        exhale.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation){
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }


}


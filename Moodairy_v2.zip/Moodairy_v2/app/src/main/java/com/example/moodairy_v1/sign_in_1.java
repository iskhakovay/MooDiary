package com.example.moodairy_v1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class sign_in_1 extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_back_signin, btn_next;
    EditText et_new_user_name, et_new_user_email, et_new_user_phone;
    SharedPreferences user_data;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_in_1);
        user_data = getSharedPreferences("pass_and_mail",MODE_PRIVATE);
        et_new_user_email = findViewById(R.id.et_new_user_email);
        et_new_user_name = findViewById(R.id.et_new_user_name);
        et_new_user_phone = findViewById(R.id.et_new_user_phone);
        btn_back_signin = findViewById(R.id.btn_back_signin);
        btn_next = findViewById(R.id.btn_next);

        btn_next.setOnClickListener(this);
        btn_back_signin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == btn_back_signin){
            Intent intent = new Intent (sign_in_1.this, MainActivity.class);
            startActivity(intent);

        }
        if(view == btn_next){
            SharedPreferences.Editor myEdit = user_data.edit();
            Intent intent1 = new Intent(sign_in_1.this, sign_in_2.class);
            intent1.putExtra("USER_EMAIL",et_new_user_email.getText().toString());
            intent1.putExtra("USER_NAME",et_new_user_name.getText().toString());
            myEdit.putString("EMAIL",et_new_user_email.getText().toString());
            myEdit.commit();
            startActivity(intent1);


        }
    }

}
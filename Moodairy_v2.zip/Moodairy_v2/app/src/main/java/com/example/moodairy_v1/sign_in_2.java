package com.example.moodairy_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class sign_in_2 extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_back, btn_signin;
    EditText et_new_user_pass, et_new_user_pass2;
    SharedPreferences user_data;
    String user_pass="", TAG = "tag";
   // private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_in_2);
        user_data = getSharedPreferences("pass_and_mail",MODE_PRIVATE);
        btn_back = findViewById(R.id.btn_back_signin2);
        btn_signin = findViewById(R.id.btn_signin2);
        et_new_user_pass = findViewById(R.id.et_new_user_pass);
        et_new_user_pass2 = findViewById(R.id.et_new_user_pass2);

        btn_back.setOnClickListener(this);
        btn_signin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if(view == btn_back){
            Intent intent2 = new Intent(sign_in_2.this, sign_in_1.class);
            startActivity(intent2);
        }
        if(view == btn_signin){
            Intent intent1 = getIntent();
            String USER_NAME = intent1.getStringExtra("USER_NAME");
            String USER_EMAIL = intent1.getStringExtra("USER_EMAIL");
            if(et_new_user_pass2.getText().toString().equals(et_new_user_pass.getText().toString())){
                SharedPreferences.Editor myEdit = user_data.edit();
                myEdit.putString("USER_PASSWORD",et_new_user_pass.getText().toString());
                myEdit.commit();
            }
            if(et_new_user_pass2.getText().toString().equals(et_new_user_pass.getText().toString())) {
                Intent intent = new Intent(sign_in_2.this,MainActivity.class);
                intent.putExtra("USER_EMAIL",USER_EMAIL);
                intent.putExtra("USER_PASSWORD",et_new_user_pass.getText().toString());
                startActivity(intent);

            }
            else {
                Toast.makeText(this,"Your passwords doesn't match. Please check again.",Toast.LENGTH_LONG).show();
            }

        }

    }






}
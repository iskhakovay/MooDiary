package com.example.moodairy_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_signin, btn_login, btn_forgot_pass;
    SharedPreferences user_data;
    SharedPreferences.Editor myEdit;
    int SIGN_UP=0, LOG_IN=1;
    private FirebaseAuth mAuth;
    String USER_PASSWORD="default", USER_NAME, USER_EMAIL="default", TAG = "tag";
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        user_data = getSharedPreferences("pass_and_mail", MODE_PRIVATE);
        myEdit = user_data.edit();
        myEdit.putString("USER_EMAIL",USER_EMAIL);
        myEdit.putString("USER_PASSWORD",USER_PASSWORD);
        myEdit.commit();
        mAuth = FirebaseAuth.getInstance();
        btn_forgot_pass = findViewById(R.id.btn_forgot_pass);
        btn_login = findViewById(R.id.btn_log_in_1);
        btn_signin = findViewById(R.id.btn_signin2);

        Intent intent = getIntent();
        USER_PASSWORD = intent.getStringExtra("USER_PASSWORD");
        USER_EMAIL = intent.getStringExtra("USER_EMAIL");
        USER_NAME = intent.getStringExtra("USER_NAME");
        if(USER_EMAIL!=null && USER_PASSWORD!=null) {
            mAuth.createUserWithEmailAndPassword(USER_EMAIL, USER_PASSWORD)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "createUserWithEmail:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                //updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                Toast.makeText(getApplicationContext(), "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                                //updateUI(null);
                            }

                            // ...
                        }
                    });
        }
        /*else{
            Toast.makeText(this,"Data is null",Toast.LENGTH_LONG).show();
        }*/

        btn_signin.setOnClickListener(this);
        btn_login.setOnClickListener(this);
        btn_forgot_pass.setOnClickListener(this);

    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
       // updateUI(currentUser);
    }
    @Override
    public void onClick(View view) {


        if(view == btn_login){
            Intent intent1 = new Intent(MainActivity.this, log_in.class);
            intent1.putExtra("USER_EMAIL",user_data.getString("USER_EMAIL",USER_EMAIL));
            intent1.putExtra("USER_PASSWORD",user_data.getString("USER_PASSWORD",USER_PASSWORD));
            startActivity(intent1);
        }
        if(view == btn_signin){
            Intent intent2 = new Intent(MainActivity.this, sign_in_1.class);
            myEdit.putString("USER_EMAIL",USER_EMAIL);
            myEdit.putString("USER_PASSWORD",USER_PASSWORD);
            myEdit.commit();
            startActivity(intent2);


        }
        if(view == btn_forgot_pass){

            Intent intent3 = new Intent(MainActivity.this, forgot_password_1.class);
            intent3.putExtra("USER_EMAIL",USER_EMAIL);
            startActivity(intent3);

        }

    }



}
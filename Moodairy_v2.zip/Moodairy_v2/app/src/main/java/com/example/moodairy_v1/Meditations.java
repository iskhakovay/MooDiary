package com.example.moodairy_v1;

public class Meditations {
    private int time;
    private int date;
    public void Medtitation(int time, int date) {
        this.date = date;
        this.time = time;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

}

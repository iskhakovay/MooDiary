package com.example.moodairy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class home_screen extends AppCompatActivity implements View.OnClickListener {
    EditText et_note;
    FloatingActionButton fb_main, fb_meditation ,fb_stats, fb_help, fb_mood, fb_calendar;
    ImageButton btn_log_out, btn_setting, dialog_mood_happy, dialog_mood_normal, dialog_mood_okay, dialog_mood_br, dialog_mood_sad;
    Animation rotateOpen, rotateClose, from_btn, to_btn, from_btn2, to_btn2;
    Boolean click = false;
    Dialog dialog;
    int happy = 100, normal = 50, okay = 0 , br = -50, sad = -100;
    int current_mood;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home_screen);

        et_note = findViewById(R.id.et_note);
        fb_calendar = findViewById(R.id.fb_calendar);
        fb_help = findViewById(R.id.fb_help);
        fb_main = findViewById(R.id.fb_main);
        fb_meditation = findViewById(R.id.fb_meditation);
        fb_stats = findViewById(R.id.fb_stat);
        fb_mood = findViewById(R.id.fb_mood);
        btn_log_out = findViewById(R.id.btn_log_out);
        btn_setting = findViewById(R.id.btn_settings);

        rotateOpen = AnimationUtils.loadAnimation(this, R.anim.rotate_open_anim);
        rotateClose = AnimationUtils.loadAnimation(this, R.anim.rotate_close_anim);
        to_btn = AnimationUtils.loadAnimation(this, R.anim.to_button_anim);
        from_btn = AnimationUtils.loadAnimation(this, R.anim.from_button_anim);
        from_btn2 = AnimationUtils.loadAnimation(this, R.anim.from_button_anim_stats);
        to_btn2 = AnimationUtils.loadAnimation(this, R.anim.to_button_anim_stats);

        fb_main.setOnClickListener(this);
        fb_stats.setOnClickListener(this);
        fb_calendar.setOnClickListener(this);
        fb_help.setOnClickListener(this);
        fb_mood.setOnClickListener(this);
        fb_meditation.setOnClickListener(this);
        btn_setting.setOnClickListener(this);
        btn_log_out.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == fb_main){
            click = !click;
            setVisibility(click);
            setAnimation(click);
        }
        if(view == fb_calendar){

        }
        if(view == fb_help){

        }
        if(view == fb_meditation){
            Intent intent = new Intent(home_screen.this, meditation.class);
            startActivity(intent);
        }
        if(view == fb_mood){
            build_dialog();
            if(view == dialog_mood_br){
                current_mood = br;
                dialog.dismiss();
            }
            if(view == dialog_mood_happy){
                current_mood = happy;
                dialog.dismiss();
            }
            if(view == dialog_mood_normal){
                current_mood = normal;
                dialog.dismiss();
            }
            if(view == dialog_mood_okay){
                current_mood = okay;
                dialog.dismiss();
            }
            if(view == dialog_mood_sad){
                current_mood = sad;
                dialog.dismiss();
            }


        }
        if(view == fb_stats){

        }
        if(view == btn_log_out){
            Intent intent = new Intent(home_screen.this, MainActivity.class);
            startActivity(intent);
        }

    }
    private void setVisibility(Boolean clicked){
        if(clicked){
            fb_meditation.setVisibility(View.VISIBLE);
            fb_help.setVisibility(View.VISIBLE);
            fb_calendar.setVisibility(View.VISIBLE);
            fb_stats.setVisibility(View.VISIBLE);
            fb_mood.setVisibility(View.VISIBLE);

        }
        else{
            fb_meditation.setVisibility(View.INVISIBLE);
            fb_help.setVisibility(View.INVISIBLE);
            fb_calendar.setVisibility(View.INVISIBLE);
            fb_stats.setVisibility(View.INVISIBLE);
            fb_mood.setVisibility(View.INVISIBLE);
        }

    }
    private  void setAnimation(Boolean clicked){
        if(clicked){
            fb_main.startAnimation(rotateOpen);
            fb_mood.startAnimation(from_btn);
            fb_meditation.startAnimation(from_btn);
            fb_stats.startAnimation(from_btn);
            fb_help.startAnimation(from_btn);
            fb_calendar.startAnimation(from_btn);
        }
        else{
            fb_main.startAnimation(rotateClose);
            fb_mood.startAnimation(to_btn);
            fb_meditation.startAnimation(to_btn);
            fb_stats.startAnimation(to_btn);
            fb_help.startAnimation(to_btn);
            fb_calendar.startAnimation(to_btn);
        }
    }
    private void build_dialog(){
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.mood_dialog);
        dialog.setTitle("this is dialog");
        dialog_mood_br = dialog.findViewById(R.id.btn_br);
        dialog_mood_happy = dialog.findViewById(R.id.btn_happy);
        dialog_mood_normal = dialog.findViewById(R.id.btn_normal);
        dialog_mood_okay = dialog.findViewById(R.id.btn_okay);
        dialog_mood_sad = dialog.findViewById(R.id.btn_sad);
        dialog_mood_sad.setOnClickListener(this);
        dialog_mood_okay.setOnClickListener(this);
        dialog_mood_normal.setOnClickListener(this);
        dialog_mood_happy.setOnClickListener(this);
        dialog_mood_br.setOnClickListener(this);
        dialog.setCancelable(true);
        dialog.show();
    }
}
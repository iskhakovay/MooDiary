package com.example.moodairy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;

public class forgot_passwod_2 extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_send_code_again, btn_back,btn_cont;
    EditText et_code;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_forgot_passwod_2);

        btn_back = findViewById(R.id.btn_back_orange);
        btn_cont = findViewById(R.id.btn_cont);
        btn_send_code_again = findViewById(R.id.btn_send_code_again);
        et_code = findViewById(R.id.et_code);

        btn_send_code_again.setOnClickListener((View.OnClickListener) this);
        btn_cont.setOnClickListener(this);
        btn_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = getIntent();
        int code = intent.getIntExtra("CODE",0);
        if(view == btn_back){
            Intent intent1 = new Intent(forgot_passwod_2.this, forgot_password_1.class);
            startActivity(intent1);
        }
        if(view == btn_send_code_again){
            //send code
        }
        if(view == btn_cont){
            if(et_code.getText().toString().equals(code)){
                Intent intent1 = new Intent(forgot_passwod_2.this,forgot_password_3.class);
                startActivity(intent1);
            }
        }

    }
}
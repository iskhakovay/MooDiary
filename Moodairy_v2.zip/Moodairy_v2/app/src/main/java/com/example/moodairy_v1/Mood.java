package com.example.moodairy_v1;

public class Mood {
    int mood_id,date;

    public int getMood_id() {
        return mood_id;
    }

    public void setMood_id(int mood_id) {
        this.mood_id = mood_id;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public Mood(int mood_id, int date) {
        this.mood_id = mood_id;
        this.date = date;
    }

}

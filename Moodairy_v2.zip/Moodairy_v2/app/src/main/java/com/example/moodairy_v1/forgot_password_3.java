package com.example.moodairy_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class forgot_password_3 extends AppCompatActivity implements View.OnClickListener {
    ImageButton btn_back, btn_reset;
    EditText et_pass, et_pass_2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_forgot_password_3);

        btn_back = findViewById(R.id.btn_back_orange_2);
        btn_reset = findViewById(R.id.btn_reset_pass);
        et_pass = findViewById(R.id.et_pass);
        et_pass_2 =findViewById(R.id.et_pass_2);

        btn_reset.setOnClickListener(this);
        btn_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(btn_back == view){
            Intent intent =  new Intent(forgot_password_3.this, forgot_passwod_2.class);
            startActivity(intent);
        }
        if( btn_reset == view){
            if(et_pass_2.getText().toString().equals(et_pass.getText().toString())){
                Intent intent = new Intent(forgot_password_3.this, MainActivity.class);
                intent.putExtra("USER_PASSWORD",et_pass.getText().toString());
                startActivity(intent);
            }
            else{
                Toast.makeText(this,"Passwords don't match. Please check and try again",Toast.LENGTH_LONG).show();
            }
        }

    }
}
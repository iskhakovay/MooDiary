package com.example.moodairy_v1;

public class Notes {
    private String note, data;

    public void Notes (String note, String data){
        this.note = note;
        this.data = data;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
